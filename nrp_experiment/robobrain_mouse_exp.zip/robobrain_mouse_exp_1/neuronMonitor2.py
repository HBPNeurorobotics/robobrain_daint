@nrp.NeuronMonitor(nrp.brain.M1_L1_ENGC + nrp.brain.M1_L1_SBC + nrp.brain.M1_L23_CC, nrp.spike_recorder)
def neuronMonitor2 (t):
    return True