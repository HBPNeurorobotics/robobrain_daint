@nrp.NeuronMonitor(nrp.brain.M1_L1_ENGC + nrp.brain.M1_L1_SBC, nrp.spike_recorder)
def neuronMonitor (t):
    return True